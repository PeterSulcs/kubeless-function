from process import process_wrapper

if __name__ == "__main__":
    result = process_wrapper({"data":b'64'},{})
    print(result)